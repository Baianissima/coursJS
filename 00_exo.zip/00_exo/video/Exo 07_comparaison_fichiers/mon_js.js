// Une fonction, appellée après pour s'afficher l'alerte et vérifier les autres pages aussi

    function coucou() {
    return alert('Olá! Carpe diem!');
}
