// le script JS pour exo 02_exo_valeurs

//  barre bolique opposée \
// == veut dire : equivaut à, égal à
// = veut dire : contient
// += veut dire :
// typeof : c'est NUMBER, des chiffres
// string : c'est une chaîne de caractères, entre des quotes simples ' '
// != veut dire : différent de
// * multiplier
// *= ???
// € = altGr + E

alert('Bonjour !');

var a = 2;
console.log(a);






















//pour tester sur la console avant ed commencer :  alert('Bonjour !');

// let prenom =  prompt ('Votre prénom');
// console.log(prenom);

// let nom = prompt('Votre nom');
// console.log(nom);

// alert('Bonjour, ' + prenom + ' ' + nom + ' ! ');

//MODELE POUR ECRIRE : alert('   '+ X +'    '+ X +'    ');



// ou cette autre façon de faire avec :

// let prenom;
// prenom = prompt('Votre prénom');
// console.log(prenom);

// let nom;
// nom = prompt('Votre nom');
// console.log(nom);

// alert('Bonjour, ' + prenom + ' ' + nom + ' ! ');




// 
// VERSION DE RACHID avec mes commentaires : decommenter pour la voir :

// Ici on cree les 2 varaibles :

// let questionPrenom = 'Quel est votre prénom ?';
// let questionNom = 'Quel est votre nom ?';

// Ici on fait apparaitre les 2 fenetres a taper les mots dedans avec PROMPT :

// let prenom = prompt(questionPrenom);
// let nom = prompt(questionNom);

// Ici console.clear permet de nettoyer la console :

// console.clear();

// Ici on cree la console pour verifier que les NOM et PRENOM s affichent correctement :

// console.log(prenom, nom);

// Ici on cree l'alerte qui contiendra la chanîe de caracteres entres des quotes avec le nom et le prenom tapés dans les prompts :

// alert('Bonjour, ' + prenom + ' ' + nom+ ' !');




        
        
        
        








