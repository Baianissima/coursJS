violent-theremin
================

Violent theremin uses the Web Audio API to generate sound, and HTML5 canvas for a bit of pretty visualization. The colours generated depend on the pitch and gain of the current note, which are themselves dependant on the mouse pointer position.

You can [view the demo](http://mdn.github.io/violent-theremin/) live here.
