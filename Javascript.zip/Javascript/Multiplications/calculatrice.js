var clear=false;

// lorsqu'on a pas mis onclick="" dans l'élément HTML, on peut le mettre via JAVASCRIPT:
// --> on récupère la liste des boutons puis on ajoute à chacun, l'évènement ONCLICK
let lstBoutons = document.getElementsByTagName("button");
for (i=0; i<lstBoutons.length; i++) 
    lstBoutons[i].addEventListener("click", function() {touche(this)});

function touche(bouton) {
    let affichage = document.getElementById("affichage");

    // Méthode avec SWITCH
    switch(bouton.innerText) {
        case "C":   // on efface tout
            affichage.innerText = "" ;
            break;

        case "<-":  // on enlève le dernier caractère
            affichage.innerText=affichage.innerText.slice(0,-1) ;
            break;
        
        case "=":   // on affiche le résultat sur la ligne suivante
            let result=eval(affichage.innerText);
            affichage.innerHTML += "<br>= "+result ;
            clear=true;
            break;

        default:
            if(clear) { // on écrase le résultat précédent en affichant la touche cliquée
                affichage.innerText = bouton.innerText;
                clear=false;
            }
            else    // la touche cliquée est concaténée sur l'afficheur
                affichage.innerText += bouton.innerText;
        }
    return;

    // Méthode avec IF
    if (bouton.innerText == "C") {
        affichage.innerText = "" ;
        return;
    }
    if (bouton.innerText == "<-") {
        affichage.innerText=affichage.innerText.slice(0,-1) ;
        return;
    }
    if (bouton.innerText == "=") {
        let result=eval(affichage.innerText);
        affichage.innerHTML += "<br>= "+result ;
        clear=true;
    }
    else {
        if(!clear)
            affichage.innerText += bouton.innerText;
        else {
            affichage.innerText = bouton.innerText;
            clear=false;
       }
    }
}