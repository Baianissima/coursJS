let main = document.querySelector("main");
main.style.display="block";
main.style.display="grid";

for(j=1; j <= 12; j++) {
    let table = document.getElementById("tab_"+j) ;
    table.innerHTML="<h4>Table de " + j + "</h4><hr>";
    console.log("Table de " + j); 
    for(i=1; i<=12; ++i) {
        console.log(i + " x " + j + " = " + j*i); 
        table.innerHTML+="<br>"+ i + " x " + j + " = " + j*i ;
    }
};

function dispTable(el) {
    area=document.getElementById("afficheur");
    table = el.innerText ;
    area.innerHTML="<h4>Table de " + table + "</h4><hr>";
    for(i=1; i<=12; ++i) {
        console.log(i + " x " + table + " = " + table*i); 
        area.innerHTML+="<br>"+ i + " x " + table + " = " + table*i ;
    }
}