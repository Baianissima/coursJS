let nbCircle = nbCarre = 0      // nombres de carrés et de cercles créés
let divMouse = null             // afficheur des coordonnées souris
let listItems = []              // liste de tous les éléments
let listMoving = []             // liste des éléments en mouvement
let intervalID = null           // handle du timer de mouvement
let nZindex = 1                 // gestion des zIndex

let bouton = document.createElement("button")
bouton.onclick = function(){newItem(this)}
bouton.innerText = "Essai"
document.querySelector("#dispmouse").before(bouton)

let elMotion = document.getElementById("motion")
// récupération du pointeur sur le conteneur
let mainDiv = document.querySelector("main")
// centrage horizontal et vertical (sans margin: auto)
centreElement(mainDiv)
// on recentre le conteneur si la fenêtre change de dimension
window.onresize = () => centreElement(mainDiv)
// on autorise le déplacement uniquement dans le conteneur "main"
// (permet d'afficher une icone interdiction qd on sort de la zone)
mainDiv.ondragover = function(event) { event.preventDefault()}
// pour affichage des coordonnées souris
document.addEventListener("mousemove", logEvent);

// centre un élément dans le viewport ou l'élément parent
function centreElement(element) {
    // centrage vertical
    if(element.parentNode.nodeName == "BODY")       // centrage dans la fenêtre (le parent est "body")
       element.style.top = (window.innerHeight - element.offsetHeight) / 2 + "px"
    else                                            // centrage dans l'élément parent
       element.style.top = (element.parentNode.clientHeight - element.offsetHeight) / 2 + "px"
    // centrage horizontal
    if(element.parentNode.nodeName == "BODY")
       element.style.left = (window.innerWidth - element.offsetWidth) / 2 + "px"
    else
       element.style.left = (element.parentNode.clientWidth - element.offsetWidth) / 2 + "px"
    // // centrage vertical
    // element.style.top = (window.innerHeight - element.offsetHeight) / 2 + "px"
    // // centrage horizontal
    // element.style.left = (window.innerWidth - element.offsetWidth) / 2 + "px"
}
// création d'un nouvel élément (carré ou cercle) que l'on ajoute dans le cadre (mainDiv)
function newItem(el) {
    let item = document.createElement("div")
    item.draggable = true
    // item.style.position = "absolute"
    item.addEventListener("click", function() {zIndex(item)})
    item.addEventListener("dragstart", dragStart)
    item.addEventListener("dragend", dragEnd)
    item.addEventListener("drag", dragLimites)
    // vitesses sur X et Y quand l'élément sera mis en mouvement (au double clic)
    item.velX = 1
    item.velY = 2
    item.ondblclick = toggleMouvement       
    // placement des nouveaux éléments avec un léger décalage pour plus de visibilité
    item.style.left = (nbCircle+nbCarre)*5 + "px"
    item.style.top = (nbCircle+nbCarre)*30 + "px"
    // ajout de la classe et du texte interne
    switch(el.innerText) {
        case "Carré":
            item.className = "carre"
            item.innerText = `${el.innerText} ${++nbCarre}`     // 1ere méthode pour formater la chaine
            item.rotate = false     // ajout propriété "rotate" pour gérer rotation des carrés lors d'1 collision
            break
        case "Cercle":
            item.className = "cercle"
            item.innerText = el.innerText + " " + ++nbCircle    // 2eme méthode pour formater la chaine
            break
    }
    item.style.backgroundColor = randomColor()
    item.style.zIndex = "1"
    listItems.push(item)    // ajout de l'élément dans la liste des éléments 
    mainDiv.append(item)    // ajout/affichage de l'élément dans le conteneur
}

//div1.addEventListener("drag", logEvent) // affichage des coordonnées souris quand drag

function dragStart(event) { 
    // au départ du drag, on mémorise la position de la souris
    // au moment du drop, la différence entre la nouvelle position et celle mémorisée donne le déplacement
    posX = event.clientX 
    posY = event.clientY 
    // event.target.style.position = "absolute"     // l'élément doit être en "absolute"

    // icone de déplacement "move"
    event.dataTransfer.effectAllowed = "move";
}
function dragEnd(event) {
    let item = event.target         // pour simplifier la lecture du code

    // positionnement sur l'axe des X
    item.style.left = (event.clientX - posX) + item.offsetLeft + "px"
    // positionnement sur l'axe des Y
    item.style.top = (event.clientY - posY) + item.offsetTop + "px"
    
    checkLimites(item)
    zIndex(item)
}
function checkLimites(item) {
    // le bord gauche sort du cadre ?
    if(item.offsetLeft <= 0) {
        item.style.left = "0px"
        item.velX = -(item.velX);   //inversion de la vitesse horizontale (velX)
    }
    // le bord supérieur sort du cadre ?
    if(item.offsetTop <= 0) {
        item.style.top = "0px"
        item.velY = -(item.velY)    //inversion de la vitesse verticale (velY)
    }
    
    // le bord droit sort du cadre ?
    // mainDiv.clientWidth = largeur du cadre (sans bordures)
    // item.offsetWidth = largeur de l'élément déplacé (avec bordures)
    if((item.offsetLeft + item.offsetWidth) >= mainDiv.clientWidth){
        item.style.left = (mainDiv.clientWidth - item.offsetWidth) + "px"
        item.velX = -(item.velX);   //inversion de la vitesse horizontale (velX)
    }
    
    // le bord inférieur sort du cadre ?
    // mainDiv.clientHeight = hauteur du cadre (sans bordure)
    // item.offsetHeight = hauteur de l'élément déplacé
    if((item.offsetTop + item.offsetHeight) >= mainDiv.clientHeight) {
        item.style.top = (mainDiv.clientHeight - item.offsetHeight) + "px"
        item.velY = -(item.velY);   //inversion de la vitesse verticale (velY)
    }
}
// pour tests
function dragLimites(event) {
    if(event.target.offsetLeft < 0)
        console.log("limite")
}
// met au premier plan l'élément sélectionné
function zIndex(item) {
    // Méthode prenant en compte l'ordre des précédents clics
    // on incrémente tout simplement une variable nZindex 
    item.style.zIndex = ++nZindex
    return
    // Méthode 2 (pour s'exercer à la manipulation des tabeaux):
    //  ne tient pas compte de l'ordre des précedents clics
    // -> on met zIndex à 1 sur tous les éléments
    for(i of listItems) 
        i.style.zIndex = "1"
    // autre façon de faire: avec la méthode "map" de Array où on appelle 1 fonction 
    // listItems.map( function(i) {i.style.zIndex = "1"})   , ou encore:
    // listItems.map( (i) => i.style.zIndex = "1")

    // on met en avant l'élément cliqué
    item.style.zIndex = "10"
}
// renvoie une couleur aléatoire
function randomColor() {
    // random() renvoie un nombre décimal entre 0 et 1
    // floor() enlève la partie décimale (garde la partie entière)
    // -> on obtient des entiers entre 0 et 255
    var x = Math.floor(Math.random() * 255);
    var y = Math.floor(Math.random() * 255);
    var z = Math.floor(Math.random() * 255);
    // mise au format "rgb(r, v, b)"
    var bgColor = "rgb(" + x + "," + y + "," + z + ")";
    return bgColor
}
// affiche les coordonnées de la souris
function logEvent (event) {
    if(divMouse==null)
        divMouse = document.getElementById("dispmouse");
    // 2 façons d'écrire la même chose:
    // let msg = "x: " + event.clientX + " , y: " + event.clientY  ;
    let msg = `(${event.clientX},${event.clientY})`
    divMouse.innerText = msg;
}
// mise en mouvement d'un élément (doubleclic)
// un second doubleclic arrête le mouvement
function toggleMouvement(event) {
    // démarrage du timer si arrêté
    if(intervalID==null)
        intervalID = setInterval(moveItem, 50)
    // si élément à l'arrêt: on l'anime en l'ajoutant à la liste des éléments en mouvement
    // si élément déjà en mouvement: on l'arrête en le sortant de la liste
    let index = listMoving.indexOf(event.target)
    if(index < 0)
        listMoving.push(event.target)   // ajout
    else
        listMoving.splice(index,1)      // retrait
    // arrêt du timer si plus d'élément en mouvement
    if(listMoving.length==0) {
        clearInterval(intervalID); 
        intervalID=null; 
        elMotion.style.display="none"   // on fait disparaitre le bloc "Motion"
    }
    else
        elMotion.style.display="flex"   // on affiche le bloc "Motion"
}
// Mise en pause/start des éléments en mouvement (appui sur bouton "pause/start")
// -> pause = arrêt du timer, start = relance du timer
function toggleTimer(idTimer) {
    if(intervalID==null)
        {intervalID = setInterval(moveItem, 50); document.getElementById("pauseMotion").innerText="Pause"}
    else
        {clearInterval(intervalID); intervalID=null; document.getElementById("pauseMotion").innerText="Start"}
    
}
// Arrêt total des mouvements en arrêtant le timer et en effaçant tous les éléments de la liste
function stopTimer() {
    clearInterval(intervalID); 
    intervalID = null
    listMoving = []
}
// appelée par le timer (x fps)
// mise à jour de la position de tous les éléments en mouvement
function moveItem() {
    for(item of listMoving) {
        item.style.top = (item.offsetTop + item.velY) + "px"
        item.style.left = (item.offsetLeft + item.velX) + "px"
        checkLimites(item)      // l'élément sort-il du cadre ?
        detectCollision(item)
        // affichage des vitesses dans les 2 éléments en collision (pour tests)
        i.innerText = "("+i.velX+","+i.velY+")"
        item.innerText = "("+item.velX+","+item.velY+")"
}
}
function detectCollision(item) {
    // on parcourt la liste de tous les éléments
    for(i of listItems) {
        if(item == i) continue      // l'élément ne peut être en collision avec lui même
        // on calcule le deltaX et le deltaY 
        // calcul avec le centre des éléments
        // let dX = (i.offsetLeft+i.offsetWidth/2) - (item.offsetLeft+item.offsetWidth/2)
        // let dY = (i.offsetTop+i.offsetHeight/2) - (item.offsetTop+item.offsetHeight/2)

        // calcul avec le bord supérieur gauche (+ simple mais risque si les éléments n'ont pas la même dimension, à vérifier)
        let dX = i.offsetLeft - item.offsetLeft
        let dY = i.offsetTop - item.offsetTop
        // distance entre les éléments = racine carré de (dX² + dY²)
        let distance = Math.sqrt(dX*dX + dY*dY)
        // si distance < largeur de l'élément -> collision (risque si les éléments n'ont pas la même dimension)
        if (distance < item.offsetWidth) {
            // si l'élément heurté est à l'arrêt -> on le met en mouvement en l'ajoutant à la liste des éléments en mouvement
            if(listMoving.indexOf(i) == -1) 
                listMoving.push(i)
            // Effet 1: les objets partent dans des sens opposés
            // i.velY = item.velY
            // item.velY = -item.velY

            // Effet 2: vitesse verticale proportionnelle au deltaY et sens opposés
            // (la nouvelle vitesse dépend du point d'impact)
            i.velY = dY/10
            item.velY = -i.velY
            // vitesse horizontale proportionnelle au deltaX (idem)
            i.velX = dX/10
            item.velX = -i.velX

            // Effet 3: les cercles deviennent des carrés et vice-versa
            // i.style.transition="border-radius 1s"
            // if(i.className=="carre") 
            //     i.className="cercle"
            // else 
            //     i.className="carre"

            // rotation des carrés
            if(i.className!=item.className) {
                rotateItem(i)
                rotateItem(item)
            }
        }
    }
}
// effet de rotation sur un carré quand il est heurté par un cercle
function rotateItem(item) {
    if(item.className=="cercle") return
    item.style.transition="transform 1s"
    if(item.rotate) { 
        item.style.transform = ""; 
        item.rotate=false
    }
    else {  
        item.style.transform="rotateZ(360deg)"; 
        item.rotate=true
    }
}