var count=0 ;
let timePrecision = 1/10 ;  // 1/10: dizième de seconde (1/100: centième, 1/1000: millième, 1: seconde)
let step = 1000*timePrecision ;
var handleInterval=null ;
let dispChrono ;
let affichage = document.getElementById("afficheur");
let listBouton = document.getElementsByTagName("button");
let dispLapTime = document.getElementById("temps");

affichage.innerText = "00' 00'' 000" ;

for (i of listBouton) {
    i.addEventListener("click", function() {manageButton(this)});
}
function timer() {
    let heures=0, minutes=0, secondes=0, millis=0 ;
    let temp ;

    count += step ;
    sec = Math.floor(count/1000) ;
    millis = (count%1000);
    heures = Math.floor(sec/3600);
    minutes = Math.floor((sec - (heures*3600)) / 60) ;
    secondes = sec - (heures*3600) - (minutes*60);
    secondes = Math.round(secondes*100)/100;

    heures = (heures < 10 ? "0" + heures : heures);
    minutes = (minutes < 10 ? "0" + minutes : minutes);
    secondes = (secondes < 10 ? "0" + secondes : secondes);
    millis = (millis == 0 ? "000" : millis);

    dispChrono = minutes + "' " + secondes+ "'' " +millis ;
    affichage.innerText = minutes + "' " + secondes+ "'' " +millis ;
    // affichage.innerText = convertionSecondes(sec) + " : " + millis;
    return;
    millis = tmp%(1000/step);
    tmp = (tmp-millis)/10 ;
    secondes = tmp%60 ;
    minutes = (tmp-secondes)/60;
    dispChrono = minutes + "' " + secondes+ "'' " +millis ;
    affichage.innerText = dispChrono;
}

function convertionSecondes(sec) 
 {
     var hours = Math.floor(sec / 3600);
     var minutes = Math.floor((sec - (hours * 3600)) / 60);
     var seconds = sec - (hours * 3600) - (minutes * 60);
     seconds = Math.round(seconds * 100) / 100
     
     var result = (hours < 10 ? "0" + hours : hours);
     result += "-" + (minutes < 10 ? "0" + minutes : minutes);
     result += "-" + (seconds < 10 ? "0" + seconds : seconds);
     return result;
}

function manageButton(element) {
    switch(element.id) {
        case "bouton_1":
            if(handleInterval) {
                element.innerText = "Start" ;
                affichage.className = "blink" ;
                clearInterval(handleInterval);
                handleInterval=null;
                return;
            }
            handleInterval = setInterval(timer, step);
            element.innerText="Stop";
            affichage.className = "" ;
            break
        case "bouton_2":
            dispLapTime.innerText += "\n" + dispChrono;
            break;
        case "bouton_3":
            clearInterval(handleInterval);
            affichage.innerText = "0";
            affichage.className = "" ;
            count=0;
            handleInterval=null;
            return;

            if(element.innerText=="Stop") {
                affichage.className = "blink" ;
                element.innerText = "Reset";
            } else if (element.innerText == "Reset") {
                affichage.innerText = "0";
                element.innerText = "Stop";
                count=0;
                affichage.className = "" ;
            }
            break
    }
}