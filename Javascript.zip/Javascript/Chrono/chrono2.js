// import ./chrono1.js :

// prepend(): insérer un nœud ou du texte avant le premier enfant d’un certain nœud
// append(): insérer un nœud ou du texte après le dernier enfant de ce nœud
// appendChild(): ajoute 1 nœud en tant que dernier enfant d’1 nœud parent
//
// Exemples:
//      Ajoute l'élément "newP" comme premier enfant de l'élément "bDiv"
//      bDiv.prepend(newP);

//      Ajoute l'élément "nexTexte" comme dernier enfant de l'élément "bDiv"
//      bDiv.append(newTexte);

//      Ajoute les élément "newP" et "nexTexte" comme derniers enfants de l'élément "bDiv"
//      bDiv.append(newP, newTexte);


// Les différences entre append() de ParentNode et appendChild() de Node sont les suivantes :
// - append() permet également d’ajouter directement une chaine de caractères 
//  tandis que appendChild() n’accepte que des objets de type Node 
// - append() peut ajouter plusieurs nœuds et chaines de caractères au contraire de appendChild() 
//  qui ne peut ajouter qu’un nœud à la fois ;
// - append() n’a pas de valeur de retour, tandis que appendChild() retourne l’objet ajouté.

// insertBefore(): insérer un nœud en tant qu’enfant d’un autre nœud juste avant un certain 
//  nœud enfant donné de ce parent.

// Cette méthode va prendre en arguments le nœud à insérer et le nœud de référence 
//  c’est-à-dire le nœud juste avant lequel le nœud passé en premier argument doit être inséré.


let mainDiv = document.createElement("main");
mainDiv.draggable = true

let affichage = document.createElement("div");
affichage.id = "afficheur";
affichage.innerText = "0' 00'' 00";
mainDiv.appendChild(affichage);

let controle = document.createElement("div");
controle.id = "controle" ;
// mainDiv.appendChild(controle);

let temps = document.createElement("div");
temps.id = "temps" ;
temps.innerText = "Temps intermédiaires" ;
// mainDiv.appendChild(temps) ;
mainDiv.append(controle,temps);

document.body.appendChild(mainDiv);

let bouton1 = document.createElement("button") ;
bouton1.id = "bouton_1";
bouton1.innerText  = "Start" ;
bouton1.onclick = function () { start(this) } ;
// controle.appendChild(bouton1);

let bouton2 = document.createElement("button") ;
bouton2.id = "bouton_2";
bouton2.innerText = "Lap";
bouton2.onclick = function () { lapTime(this)};

// controle.append(bouton2);

let bouton3 = document.createElement("button") ;
bouton3.id = "bouton_3";
bouton3.innerText = "Reset";
bouton3.onclick = function () { reset()};

// controle.appendChild(bouton3);
controle.append(bouton2,bouton3);
controle.prepend(bouton1);

let dateHeure = document.createElement("h4") ;
dateHeure.innerText = "Date du Jour" ;
dateHeure.style.color = "white" ;
mainDiv.prepend(dateHeure) ;

let dispMouse = document.createElement("div")
dispMouse.id = "dispmouse"
dispMouse.style.position = "fixed"
dispMouse.style.top = "100px"
dispMouse.style.left = "10px"
document.body.prepend(dispMouse)
