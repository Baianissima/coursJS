let intervalID = null ;
let compteur = 0 ;
let secondes=0, minutes=0, heures=0 ;
let divMouse ;
let posX = posY = 0

setInterval(dispHeure, 1000);

if (affichage == undefined)
    {let affichage = document.getElementById("afficheur") ;}



let div1 = document.createElement("section");
div1.draggable = true ;
div1.style.position = "absolute"
div1.style.borderRadius = "10px"
div1.style.width = "100%"
div1.style.height = "25px"
div1.style.backgroundColor = "#0f868a"

// div1.style.top = mainDiv.offsetTop + mainDiv.offsetHeight + 30 + "px"
// div1.onclick = start ; //x  function() {start(null)} ;

let circle = document.createElement("div")
circle.style.width = "20px " ;
circle.style.height = "20px " ;
circle.style.backgroundColor = "yellow" ;
circle.style.border = "1px solid red";
circle.style.borderRadius = "50%";
circle.style.position = "absolute" ;

div1.append(circle)
document.body.prepend(div1) ;


function dispHeure() {
    let date1 = new Date();

    let dateLocale = date1.toLocaleString('fr-FR',{
    weekday: 'short',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric'});

    document.querySelector('h4').innerHTML = dateLocale;
}

function start(element) {
    if(intervalID == null) {
        intervalID = setInterval( timer, 10) ;
        element.innerText = "Stop" ;
    } else {
        clearInterval(intervalID ) ;
        element.innerText = "Start" ;
        intervalID = null ;
    }
}
function lapTime(element) {
    // document.getElementById("temps").innerText += "\n" + affichage.innerText ;
    let newLine = document.createElement("p");
    newLine.className = "ligne" ;
    newLine.style.color = "red" ;
    newLine.innerText = affichage.innerText ;
    // document.getElementById("temps").appendChild(newLine);
    // document.getElementById("temps").prepend(newLine);
    // document.getElementById("temps").childNodes[0].after(newLine);
    document.getElementById("temps").firstChild.after(newLine);
}
function reset(element) {
    compteur = 0 ;
    secondes = minutes = heures = 0 ;
    clearInterval(intervalID) ;
    intervalID = null ;
    document.getElementById("afficheur").innerText = "0' 00'' 00" ;
    document.getElementById("bouton_1").innerText = "Start" ;
    // document.getElementById("temps").innerText = "Temps intermédiaires:" ;
    let tmp = document.getElementById("temps").childNodes ;
    for (let i = tmp.length - 1, j=1111 ;  i > 0 ;  tmp[i].remove(), i--) {
            console.log(tmp[i].innerText);
            // tmp[i].remove()
    }
}

function timer() {
    compteur++ ;
    if (compteur >= 100) { secondes++ ; compteur=0}
    if (secondes >= 60) { minutes++; secondes=0}
    if (minutes >= 60) { heures++; minutes=0}

    (compteur < 10) ? dispCompteur = "0"+compteur : dispCompteur = compteur ;
    (secondes < 10) ? dispSecondes = "0"+secondes : dispSecondes = secondes ;

    affichage.innerText = minutes + "' " + dispSecondes + "'' " + dispCompteur;
    moveCircle()
}
function moveCircle () {
    if(compteur==0)
        if(circle.increase )
            circle.increase = false
        else
            circle.increase = true    

    if(circle.increase)
        circle.style.left = (compteur)+"vw" ;
    else
        circle.style.left = (100-compteur)+"vw" ;

}
circle.increase = true
document.addEventListener("mousemove", logEvent);
function logEvent (event) {
    if(divMouse==null)
        divMouse = document.getElementById("dispmouse");
    // let msg = "x: " + event.clientX + " , y: " + event.clientY  ;
    let msg = `x:${event.clientX} y:${event.clientY}, ${event.pageX} y:${event.pageY}`
    divMouse.innerText = msg;
    // if(posX) dragEnd(event)
}
// pour être repositionné, le conteneur est en position:absolute
// -> margin:auto ne fonctionne donc pas
// on le centre en javascript (+ petit décalage vers le bas)
mainDiv.style.left =  (window.innerWidth - mainDiv.offsetWidth)/2 +"px"
mainDiv.style.top = "2rem"

window.addEventListener("resize", function(){centreElement(mainDiv)})
mainDiv.addEventListener("dragstart", dragStart)
mainDiv.addEventListener("dragend", dragEnd)
function centreElement(element) {
    if(element.moved) return
    element.style.left =  (window.innerWidth - element.offsetWidth)/2 +"px"
}

div1.addEventListener("dragstart", dragStart)
div1.addEventListener("dragend", dragEnd)
div1.addEventListener("drag", logEvent) // affichage des coordonnées souris

function dragStart(event) { 
    // on détermine la position de la souris dans l'élément au départ du drag
    // pour un positionnement final sans décalage
    posX = event.clientX - event.target.offsetLeft 
    posY = event.clientY - event.target.offsetTop
    event.target.moved = true
}
function dragEnd(event) {
    event.target.style.left = (event.clientX-posX) + "px"
    event.target.style.top = (event.clientY-posY) + "px"
}