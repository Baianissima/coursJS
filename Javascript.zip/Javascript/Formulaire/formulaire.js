// Pour affichage des erreurs et des infos validées
let listeInfos = listeError = []
let nbErrors = 0

// création d'une balise <p> pour afficher les messages d'erreurs
// placée en dernier enfant des conteneurs <div> de classe "champ"
for( element of document.querySelectorAll(".champ")) {
    displayError = document.createElement("p")
    displayError.classList.add("dispError")
    element.append(displayError)
}
// création de la liste des <input> et <textarea>
let listeInput = document.querySelectorAll("input, textarea")   

// on ajoute 1 gestionnaire d'évènement pour "clic" sur "submit"
document.querySelector("form").addEventListener("submit", controleSubmit)
// autre méthode: quand "formulaire" est dans "name" (<form id="formulaire" name="formulaire" method="post"  novalidate>)
// document.formulaire.addEventListener("submit", controleSubmit)

// Rappel info: pour cibler directement les input d'un formulaire, il faut leur ajouter un "name"
//  -> on peut remplacer : document.getElementById("exp")    PAR
//  -> document.formulaire.exp       (où "name=formulaire" dans <form> et "name=exp" dans un 1 <input> enfant)

function controleSubmit(event) {
    // POUR AFFICHER LES INFORMATIONS ET/OU ERREURS
    listeInfos = ["Vos informations valides: \n"]
    listeError = []
    nbErrors = 0
    for(let inputElement of listeInput) {
        // reset pour nouveau passage dans la boucle
        isError = false
        value = ""
        inputElement.classList.remove("error")                      // suppression de la bordure rouge autour de l'input
        inputElement.parentNode.lastElementChild.innerText = ""     // suppression du texte d'erreur sous l'input

        switch(inputElement.type) {
            case "password":
                if( !(isError = checkPassword(inputElement)) )  value = inputElement.value
                break
            case "text":
            case "textarea":
                isError = checkRequired(inputElement)
                isError = checkLength(inputElement)
                value = inputElement.value
                break
            case "number":
                isError = checkRequired(inputElement)
                isError = checkMinMax(inputElement)
                value = inputElement.value
                break
            case "email" :
                isError = checkEmail(inputElement)
                value = inputElement.value
                break
            case "radio":
                isError = checkGenre(inputElement)
                if(inputElement.checked) 
                    listeInfos.push(inputElement.name + " -> " + inputElement.value)
                continue
                break
            case "checkbox":
                value = inputElement.checked ? "OUI" : "NON"
                break
            case "submit":
                continue
        }
        // SI TOUT EST OK, ON ENREGISTRE LES DONNEES DE L'INPUT DANS TABLEAU listeInfos
        if ( isError == true) {
            listeError.push("")     // pour un affichage + aéré, on saute 1 ligne 
        } else {
            // listeInfos += inputElement.id + " -> " + value + "\n"
            listeInfos.push(inputElement.id + " -> " + value )
        }
    }   // FIN FOR

// PREPARATION POUR AFFICHAGE DE LA LISTE DES ERREURS
// Méthode 1:
//      for( errorMessage of listeError ) { bilanErreurs += (errorMessage + "\n") } 
// Méthode 2:
listeError.unshift("Il y a " + nbErrors + " erreurs: \n")   // insertion du nombre d'erreur en début de tableau (1er élément)
bilanErreurs = listeError.join("\n")                        // création de la string finale à partir des messages empilés dans "listeError"
// si aucune erreur, on écrit rien (chaine vide "")
bilanErreurs = nbErrors ? bilanErreurs + "\n" : ""

// AFFICHAGE FINAL DANS LA ZONE INFERIEURE
document.getElementById("divError").innerText = bilanErreurs
document.getElementById("divSuccess").innerText = listeInfos.join("\n")

if(nbErrors){
    event.preventDefault()
    // event.stopPropagation()
} else { 
    accord = window.confirm("Les données que vous avez entré sont correctes\n Voulez-vous envoyer le formulaire au serveur ? ")
    if(accord == false)
        event.preventDefault()
    else 
        alert("Vos données ont été envoyées au serveur")
}

}   // FIN controleSubmit()

//
// FONCTIONS DE VERIFICATIONS -> retournent true quand erreur, sinon false
//
function checkLength(element) {
    if(element.value.length < element.minLength || element.value.length > element.maxLength){
        formatErrorMessage( element, "la longueur doit être comprise entre " + element.minLength + " et " + element.maxLength)
        return true}
    return false
}
function checkRequired(element) {
    if(element.required && element.value.length == 0){
        formatErrorMessage( element, "ce champ est requis")
        return true;}
    return false
    }
function checkMinMax(element) {
    if(element.value < element.min || element.value > element.max){
        formatErrorMessage( element, "l'âge doit être compris entre " + element.min + " et " + element.max + " ans")
        return true}
    return false
    }
function checkEmail(element) {
    const regex = new RegExp("[a-zA-Z0-9_-]+@[a-zA-Z0-9-]");
    if( regex.test(element.value) == false){
        formatErrorMessage( element, "doit être de la forme xxxxxx@yyyyyy")
        return true}
    return false
}
function checkGenre(element) {
    listeGenre = document.querySelectorAll("[name=sexe]")           // on cible les boutons radio du groupe "sexe"
    // On vérifie qu'un bouton est sélectionné (-> si aucun des 2 n'est checké -> erreur)
    if( !listeGenre[0].checked && !listeGenre[1].checked ){
        listeError.push(element.value + " -> " + "genre non renseigné !\n")
        element.classList.add("error")
        element.parentNode.lastElementChild.innerText = "* Homme ou Femme ?"    // mise à jour du message d'erreur (dernier enfant du conteneur parent)
        nbErrors++
        return true}
    return false
}
function checkPassword(element) {
    // const regex = new RegExp("^[a-zA-Z0-9]{8,}$")   // longueur mini de 8 avec chiffres et/ou majuscules et/ou minuscules
    const regex = new RegExp("^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])[a-zA-Z0-9]{8,}$")
    // const regex = new RegExp("^[A-Z][a-z][0-9]{8,}")    // 1 majuscule suivi d'1 minuscule puis des chiffres, longueur mini = 8
    if( regex.test(element.value) == false){
        formatErrorMessage( element, "doit contenir au moins 1 majuscule, 1 minuscule, 1 chiffre, longueur mini de 8")
        return true}
    return  false
}

// mise en forme message d'erreur
function formatErrorMessage(element,string) {
    listeError.push(element.id  + " -> " + string)                  // ajout du message à la listes des erreurs pour bilan final
    element.classList.add("error")                                  // cadre rouge autour de l'input
    element.parentNode.lastElementChild.innerText = "* " + string   // mise à jour du message d'erreur (dernier enfant du conteneur parent)
    nbErrors++                                                      // nombre total d'erreurs
    return true
}